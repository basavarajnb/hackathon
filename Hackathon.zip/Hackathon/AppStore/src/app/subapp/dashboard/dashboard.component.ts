import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  dashboardView = true;

  constructor() { }

  ngOnInit() {
  }

  ondashEntryClick(dashEntry) {
    this.dashboardView = false;

  }

  viewDashboard() {
    this.dashboardView = true;
  }


  dashEntry = [
    {
      name: "Downloaded",
      count: "23",
      image: "file_download"
    },
    {
      name: "Favourites",
      count: "7",
      image: "star"
    },
    {
      name: 'Rated',
      count: '10',
      image: 'rate_review'
    }
  ];

  dashListEntry = [
    {
      name: 'App Name',
      image: 'settings_applications',
      rating: '5'
    },
    {
      name: 'App Name2',
      image: 'settings_applications',
      rating: '5'
    },
    {
      name: 'App Name3',
      image: 'settings_applications',
      rating: '5'
    },
    {
      name: 'App Name4',
      image: 'settings_applications',
      rating: '5'
    },
    {
      name: 'App Name5',
      image: 'settings_applications',
      rating: '5'
    },
  ];

}

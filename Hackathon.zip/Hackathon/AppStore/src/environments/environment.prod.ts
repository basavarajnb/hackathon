export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyD3ONNws612TOlDkTSpMnL9xPAQlf5091w",
    authDomain: "smartpricecompare-143bb.firebaseapp.com",
    databaseURL: "https://smartpricecompare-143bb.firebaseio.com",
    storageBucket: "smartpricecompare-143bb.appspot.com",
    messagingSenderId: "956525088250"
  }
};
